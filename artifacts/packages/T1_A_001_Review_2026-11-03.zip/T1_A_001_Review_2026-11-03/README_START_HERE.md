# A-001 completed local technical review

Prepared: 2026-11-03, Beijing time. Read `git_overlay/reports/A_001_validation_2026-11-03_EN.md` first.

This delivery uses the complete original A full-r1 data package and the supplied B branch ZIP. It is supplementary verification material, not a reduced dataset or a modified data release.

## What was completed

- Independently checked all raw files, included labels and 36 feature values, exact fixed splits, B's current interface, source hashes and review cases.
- Prepared an English A-001 handoff, machine-readable evidence, population-flow explanation, source-provenance correction, and independent C/E review requests.
- Prepared a local Release metadata proposal for the unchanged full archive. It is not registered as published and is not a new formal frozen version.
- Prepared an English PR comment. Copy it only after reviewing its statements; it accurately says that these materials are local until uploaded.

## What needs the actual team

The A owner should review the technical record and provide a personal attestation. C must independently read the case evidence and check B's original trial. E with A/B/C must decide how to handle the failed event-count gates and whether to retain v1 or develop a separately versioned task. Source-license metadata also needs clarification: the official landing page names CC BY 4.0 whereas the preserved LICENSE.txt contains ODbL.

No signature, recipient acceptance, freeze, formal Release upload, PR comment, commit or remote push is performed by this delivery. Raw files, labels, splits, original manifests and B's saved trial remain unchanged. The trial's internal/external results have already been viewed; any redevelopment must disclose that exposure.

## Repository content

`git_overlay/` contains only scientific verification code, aggregate evidence and documents suitable for adding to the A branch. It contains no patient table, patient-ID split lists, raw clinical ZIPs, models or clinical trial outputs. Existing full data remain in the supplied immutable A archive. `release_preparation/` holds a truthful metadata proposal; it is not a live registry update.

`collaboration_A_update.patch` is a reviewable A-only status/changelog update based on the supplied B snapshot. Do not overwrite another member's status page with an old full-file copy. The local A checkout is separately updated only in the A row and a new dated A entry, while its other work is preserved. Synchronizing remote branches is a separate step, and this preparation does not merge B into A or main.

## Reproduce the technical audit

Run with the repository's locked dependencies. Supply the extracted full A package and the extracted B snapshot; no Git history or GitHub credentials are required.

```powershell
python scripts/verify_a001_delivery.py --a-package 'PATH_TO_FULL_A_PACKAGE' --b-root 'PATH_TO_B_BRANCH_SNAPSHOT' --output '.artifact-cache/a001-recheck'
```

The verifier reads raw data but emits only aggregate evidence. It does not call A's extractor or change data/splits. A's provided boundary tests can separately be run inside the full A package with `python -m pytest -q -p no:cacheprovider tests/test_a_cohort_v1.py`.

## Suggested next communication

Review `PR_COMMENT_EN.md`, then attach the A-001 handoff/evidence after syncing and committing the intended A files. Do not mark B's draft PR ready or merged merely because this technical audit passes. Ask C/E to record their own findings in their respective handoffs.
